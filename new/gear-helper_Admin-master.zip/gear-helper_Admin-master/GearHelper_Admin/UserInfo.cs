﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfLogin
{
    public class UserInfo
    {
        public static String CustomerName = "";
        public static String CustomerEmail = "";
    }
}